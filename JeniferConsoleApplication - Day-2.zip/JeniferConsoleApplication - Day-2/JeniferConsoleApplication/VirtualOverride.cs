﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace JeniferConsoleApplication
//{
//    //parnet/base/superclass
//    public  class Custommer
//    {

//        public virtual void Discount()
//        {
//            Console.WriteLine("10%");
//        }
//    }
//    //child/derive/subclass
//    public class GoldCustomer : Custommer
//    {
//        //method overriridng 
//        public override void Discount()
//        {

//            Console.WriteLine("15%");

//        }

//        public void GetName()
//        {


//        }

//    }



//    public class CallCls
//    {


//        static void Main()
//        {           
           
//            GoldCustomer gold = new GoldCustomer();
//            gold.Discount();
//            gold.GetName();

//            //The base class reference can point to the derive class object
//            Custommer cust = new GoldCustomer();
//            cust.Discount();
//            //cust.GetName(); it is not possible to call because only family can be call by the base class refernce

//            Console.ReadLine();


//        }

//    }

//    public class A
//    {


//        void xyz()
//        {



//        }
//    }
//}
