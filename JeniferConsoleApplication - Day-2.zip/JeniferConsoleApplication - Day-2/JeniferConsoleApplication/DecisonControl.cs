﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace JeniferConsoleApplication
//{
//    public class DecisonControl
//    {
//        //static void Main(string[] args)
//        //{
//        //    DecisonControl obj = new DecisonControl();
//        //    //obj.GetEldestOne();
//        //    //obj.GetEldestOneCodeCleanUP();
//        //    //obj.GetDemoConditonal();
//        //    obj.GetDemoSwitch();
//        //    Console.ReadLine();
//        //}

//        public void GetEldestOne()
//        {
//            int ram_age = 45, lakshmi = 50, lakshman = 40;

//            if (ram_age > lakshmi)
//            {
//                if (ram_age > lakshman)
//                {
//                    Console.WriteLine("Ram is eldest one");
//                }
//                else
//                {
//                    Console.WriteLine("Lakshman is eldest one");
//                }

//            }
//            else
//            {
//                if (lakshmi > lakshman)
//                {
//                    Console.WriteLine("Lakshmi is eldest one");
//                }
//                else
//                {
//                    Console.WriteLine("Lakshman is eldest one");
//                }

//            }

//        }

//        public void GetEldestOneCodeCleanUP()
//        {
//            int ram_age = 50, lakshmi = 70, lakshman = 60;
//            //ladders if-else
//            if (ram_age > lakshmi  && ram_age > lakshman)
//            {
//                //|| ! != 
//                Console.WriteLine("Ram is eldest one");               

//            }
//            else if (lakshmi > lakshman)
//            {
//                Console.WriteLine("Lakshmi is eldest one");            
//            }

//            else
//            {
//                Console.WriteLine("Lakshman is eldest one"); 
//            }

//        }

//        public void GetDemoConditonal()
//        {
//            int x=10,y=20;
//            int z = x > y ? x : y;
//            Console.WriteLine(z);
//            bool flag = x > y ? true : false;
//            Console.WriteLine(flag);

//        }

//        public void GetDemoSwitch()
//        {
//            Console.WriteLine("Enter the option for below:");
//            Console.WriteLine("1.Add \n2.Sub \n3.Divide");
//            int option=Convert.ToInt32( Console.ReadLine());

//            switch (option)
//            {
//                case 1:
//                    Console.WriteLine("addition will be started");
//                    break;
//                case 2:
//                    Console.WriteLine("sub will be started");
//                    break;
//                case 3:
//                    Console.WriteLine("div will be started");
//                    break;
//                default:
//                    Console.WriteLine("wrong i/p");
//                    break;
//            }
           

//        }
//    }
//}
