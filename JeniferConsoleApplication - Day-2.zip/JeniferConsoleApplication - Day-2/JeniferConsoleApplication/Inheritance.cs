﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace JeniferConsoleApplication
//{

    
//    //public class Car
//    //{
//    //    public string  TyreName { get; set; }
//    //}
//    ////Acquiring the properties the parent by the child is called inheritance 
//    ////reusability of the code 
//    //public class BMW : Car {

//    //    public void ShowTyreName() {

//    //        Console.WriteLine(TyreName);
//    //    }
    
//    //}

//    //public class Car
//    //{
//    //    public Car() {

//    //        Console.WriteLine("I am car");
//    //    }


//    //    ~Car()
//    //    {

//    //       Console.WriteLine("Hey I am from car destructor");
//    //   }
//    //}
//    ////Acquiring the properties the parent by the child is called inheritance 
//    ////reusability of the code 

//    ////order of constructor inheritance:Parent to child
//    //public class BMW : Car
//    //{

//    //   public BMW() {

//    //        Console.WriteLine("I am BMW");
//    //    }
//    //    //child executes first then parent executes
//    //    ~BMW() {

//    //       Console.WriteLine("Hey I am from BMW destructor");
//    //   }

//    //}

//    //public class CallClasses {

//    //    static void Main() {

//    //        BMW obj = new BMW();
//    //        Console.ReadLine();
        
//    //    }
    
//    //}



//    public class Car
//    {

//        public Car(int x)
//        {

//            Console.WriteLine(x);
//        }


        
//    }
//    //Acquiring the properties the parent by the child is called inheritance 
//    //reusability of the code 

//    //order of constructor inheritance:Parent to child
//    public class BMW : Car
//    {

//        public BMW(int x,int y):base(x)
//        {

//            Console.WriteLine(y);
//        }
//        //child executes first then parent executes
        

//    }

//    public class CallClasses
//    {

//        static void Main()
//        {

//            BMW obj = new BMW(2,3);
//            Console.ReadLine();

//        }

//    }
//}
