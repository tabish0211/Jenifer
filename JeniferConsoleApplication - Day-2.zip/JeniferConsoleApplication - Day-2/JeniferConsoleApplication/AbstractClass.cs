﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace JeniferConsoleApplication
//{
//    public abstract class AbstractClassDemo
//    {
//        public void CopyRights()
//        {

//            Console.WriteLine("Its my definition you cant change");

//        }

//        public abstract void Discount();

//    }

//    public class AbstractUser : AbstractClassDemo
//    {

//        public override void Discount()
//        {
//            Console.WriteLine("I am an abstarct overriden here");
//        }

//        public void abcd() { 
        
        
//        }

//    }


//    public class Calls
//    {

//        static void Main()
//        {
//            //AbstractUser obj = new AbstractUser();
//            //obj.Discount();
//            //obj.CopyRights();

//            AbstractClassDemo refc = new AbstractUser();
//            refc.Discount();
//            refc.CopyRights();
           
//            // AbstractClassDemo objdemo = new AbstractClassDemo();

//            Console.ReadLine();


//        }
//    }
//}
