﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JeniferConsoleApplication
{
    class Program
    {
        //function and method
        //when a subroutine or block of code is inside a class then it call method
        //entry point method
        static void Main(string[] args)
        {
            //o/p
            //Console.WriteLine("Hello world");
            //Console.Write("Hey i wont change line \n");
            //calling of the method

            //how to call non-static method inside static method
            //step-1 create object
            Program obj = new Program();
            //step-2
           // obj.ShowDetails();
            //obj.SumOfTheNumbers(2, 3);
            //int res=obj.SumOfTheNumbersWithReturn(3, 4);
            //Console.WriteLine("sum of the numbers:{0}", res);

            obj.Swapping(2, 3);
            Console.ReadLine();
        }


        //Definition
        public void ShowDetails() {

            string firstname, lastname;
            Console.WriteLine("Enter First name");
            //i/p
            firstname = Console.ReadLine();

            Console.WriteLine("Enter Last name");
            //i/p
            lastname = Console.ReadLine();

            Console.WriteLine("Enter Age");
            int age = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Gender M/F:");
            char gender = Convert.ToChar(Console.ReadLine());

            Console.WriteLine("Enter your salary");
            double sal = Convert.ToDouble(Console.ReadLine());
            // Console.WriteLine("Your First Name is:"+firstname);
            Console.WriteLine(@"Your Full Name is:{0} {1} and your Age is 
                                 {2} and your gender is :{3} and your salary is :{4}",
                                 firstname, lastname, age, gender, sal);
        
        }

        public void SumOfTheNumbers(int x,int y) {

            int sum = x + y;
            Console.WriteLine("sum of the numbers:{0}",sum);
        }

        public int SumOfTheNumbersWithReturn(int x, int y)
        {
            int sum = x + y;
            return sum;            
        }
        //x=2,y=3
        public void Swapping(int x, int y)
        {
            Console.WriteLine("before swapping:{0} and {1}",x,y);
            int temp;
            temp = x;//2
            x = y;//3
            y = temp;//2
            Console.WriteLine("after swapping:{0} and {1}", x, y);
           
        }

        public void SwappingWithoutThirdVariable(int x, int y)
        {
            Console.WriteLine("before swapping:{0} and {1}", x, y);
            //x=2,y=3
            x = x + y;//5
            y = x - y;//2
            x = x - y;//3          
            Console.WriteLine("after swapping:{0} and {1}", x, y);

        }
    }
}
