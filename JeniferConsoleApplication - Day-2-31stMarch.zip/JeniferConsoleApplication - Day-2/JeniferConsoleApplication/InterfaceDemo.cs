﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace JeniferConsoleApplication
//{
//    public interface IntrefaceDemoDiscount
//    {
//        //by default public--unimplemented methods
//        void Discount();
//    }

//    public interface IntrefaceDemoDiscountGold
//    {
//        void Discount();
//    }

//    //explicit interface
//    public class ChildClass : IntrefaceDemoDiscount, IntrefaceDemoDiscountGold
//    {

//        void IntrefaceDemoDiscount.Discount()
//        {
//            Console.WriteLine("10%");
//        }

//        void IntrefaceDemoDiscountGold.Discount()
//        {
//            Console.WriteLine("20%");
//        }
//    }

//    public class CallerCls
//    {


//        static void Main()
//        {

//            //ChildClass obj = new ChildClass();
//            //obj.Discount();


//            IntrefaceDemoDiscount refc = new ChildClass();
//            refc.Discount();

//            IntrefaceDemoDiscountGold refcName = new ChildClass();
//            refcName.Discount();

           
//            Console.ReadLine();



//        }
//    }
//}
