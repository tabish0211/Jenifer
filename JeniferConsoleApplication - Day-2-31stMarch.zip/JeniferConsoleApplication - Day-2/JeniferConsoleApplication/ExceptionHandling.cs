﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace JeniferConsoleApplication
//{
//      public class ExceptionHandling
//      {
//          public void DivisionWithoutExceptionHandling(int x, int y)
//          {

//              int res = x / y;
//              Console.WriteLine(res);


//          }

//          public void DivisionWithExceptionHandling(int x, int y)
//          {
//              //try
//              //{
//              //    int res = x / y;
//              //    Console.WriteLine(res);
//              //}
//              //catch (DivideByZeroException e)
//              //{
//              //    Console.WriteLine(e.Message);

//              //}        

//              //try
//              //{
//              //    //memory creation
//              //    int res = x / y;
//              //    Console.WriteLine(res);
//              //}

//              //catch (DivideByZeroException e)
//              //{
//              //    Console.WriteLine(e.Message);

//              //}
//              //finally
//              //{
//              //    Console.WriteLine("Release resource here if any you hold");
//              //}

//              try
//              {
//                  Console.WriteLine("Enter number");
//                  x = Convert.ToInt32(Console.ReadLine());

//                  Console.WriteLine("Enter number");
//                  y = Convert.ToInt32(Console.ReadLine());
//                  int res = x / y;
//                  Console.WriteLine(res);
//              }
             
//              catch (DivideByZeroException e)
//              {
//                  Console.WriteLine(e.Message);

//              }
//              catch (Exception e)
//              {
//                  Console.WriteLine(e.Message);

//              }
              
//              finally
//              {
//                  Console.WriteLine("Release resource here if any you hold");
//              }


//          }

//          public void DemoWithCustomExceptionHandling(int x, int y)
//          {
//              if (y == 0)
//              {
//                  throw new MyException("you shoud not pass second argument as zero");
//              }

//              int res = x / y;
//              Console.WriteLine(res);




//          }
//          static void Main()
//          {

//              ExceptionHandling obj = new ExceptionHandling();
//             // obj.DivisionWithoutExceptionHandling(4, 2);
//             //  obj.DivisionWithoutExceptionHandling(1, 0);
//              // obj.DivisionWithExceptionHandling(4, 2);

//               try
//               {
//                   obj.DemoWithCustomExceptionHandling(4,2);
//               }
//               catch (MyException e)
//               {

//                   Console.WriteLine(e.Message);
//               }
//              Console.WriteLine("Program Ended successfully");
//              Console.ReadLine();


//          }
//      }

//      public class MyException : Exception
//      {

//          public MyException(string message)
//              : base(message)
//          {

//          }
//      }
//}
