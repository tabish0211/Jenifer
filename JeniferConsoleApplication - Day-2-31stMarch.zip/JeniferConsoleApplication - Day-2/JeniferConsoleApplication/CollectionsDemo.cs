﻿////using System;
////using System.Collections;
////using System.Collections.Generic;
////using System.Linq;
////using System.Text;
////using System.Threading.Tasks;

////namespace JeniferConsoleApplication
////{


////    public class CollectionsDemo
////    {
////        static void Main() { 
        

////            //collection classes are used for collecting the objects
////            //Non Generic collection--Any DataType
////            ArrayList list = new ArrayList();
////            list.Add("Raju");
////            list.Add(32);
////            list.Add(12.5);
////            Console.WriteLine("It is non generic ArrayList Demo");
////            foreach (var item in list)
////            {
////                Console.WriteLine(item);
////            }

////            //Genric Collections:Specific Data Type
////            Console.WriteLine("It is generic List Demo");
////            List<string> lst = new List<string>();
////            lst.Add("Raju");
////            lst.Add("Ramesh");

////            foreach (var item in lst)
////            {
////                Console.WriteLine(item);
////            }


////            Console.ReadLine();

        
////        }
////    }
////}
