﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace JeniferConsoleApplication
//{
//    public class Bank
//    {
//        public int AccountNo { get; set; }
//        public int Amount { get; set; }
        
//        Bank()
//        {

//            AccountNo = 1001;
//            Amount = 1000;
        
//        }

//        Bank(int accountno,int amount)
//        {

//            AccountNo = accountno;
//            Amount = amount;

//        }

//        //CLR only you cant calls--Common Language Runtime--Dotnet Runner
//        ~Bank() {
//            //Memory clean up code
//            Console.WriteLine("It is Destructor");
//            Console.ReadLine();
        
//        }
//        static void Main() {
//            //Bank obj = new Bank();
//            Console.WriteLine("Enter Account number");
//            int account = Convert.ToInt32(Console.ReadLine());
//            Console.WriteLine("Enter Amount");
//            int amount = Convert.ToInt32(Console.ReadLine());

//            Bank obj = new Bank(account, amount);
//            Console.WriteLine(obj.AccountNo);
//            Console.WriteLine(obj.Amount);
//            Console.ReadLine();
        
//        }
//    }
//}
