﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JeniferConsoleApplication
{
    class ListDemos
    {
        static void Main()
        {


            //List<Employee> lst = new List<Employee>();
            ////Employee obj1 = new Employee();
            ////obj1.Name = "Raj";
            ////obj1.Id = 1001;
            ////obj1.Designation = "Software engineer";

            ////Employee obj2 = new Employee();
            ////obj2.Name = "Rahul";
            ////obj2.Id = 1002;
            ////obj2.Designation = "Senior Software engineer";

            ////Employee obj3 = new Employee();
            ////obj3.Name = "Ramesh";
            ////obj3.Id = 1003;
            ////obj3.Designation = "Lead Software engineer";

            //lst.Add(obj1);
            //lst.Add(obj2);
            //lst.Add(obj3);

            //foreach (var item in lst)
            //{
            //    Console.WriteLine(item.Id + " " + item.Name + " " + item.Designation);
            //}

            ListDemos obj = new ListDemos();
            List<Employee> listEmp = new List<Employee>();
            char ch = 'y';
            while (ch=='y')
            {
                Employee emp = obj.AddRecords();
                listEmp.Add(emp);
                Console.WriteLine("Do you want to add one more records");
                ch = Convert.ToChar(Console.ReadLine());
            }
            
            foreach (var item in listEmp)
            {
                Console.WriteLine(item.Id+" "+item.Name+" "+item.Designation);
            }
            
            //Console.WriteLine(emp.Id);
            Console.ReadLine();



        }

        public Employee AddRecords() {

            Employee obj = new Employee();
            Console.WriteLine("Enter the employee Details:");
            Console.WriteLine("Id:");
            obj.Id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Name:");
            obj.Name = Console.ReadLine();

            Console.WriteLine("Designation:");
            obj.Designation = Console.ReadLine();

            return obj;

        
        }



    }

    public class Employee {

        public int Id { get; set; }
        public string Name { get; set; }
        public string Designation { get; set; }
    
    }
}
