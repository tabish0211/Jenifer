﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using MVC_Jennifer.Models;
namespace MVC_Jennifer.Controllers
{
    public class EFformController : Controller
    {
        //
        // GET: /EFform/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Save(Employee emp)
        {
            //create object of Context class
            JenniferContext context = new JenniferContext();
            context.Set<Employee>().Add(emp);
            context.SaveChanges();
            

            return View(emp);
        }
	}
}