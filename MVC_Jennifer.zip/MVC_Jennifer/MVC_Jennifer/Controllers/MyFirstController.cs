﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_Jennifer.Controllers
{
    public class MyFirstController : Controller
    {
        //ActionMethod

        public ActionResult HelloWorld()
        {
            return View();
        }


        public ActionResult WishMe()
        {
            return View();
        }


        public ActionResult Table()
        {
            int num = 2;
            string render = string.Empty;
            for (int i = 1; i <=10; i++)
            {
                var result=num*i;
                render = render + " " + result.ToString();
            }

            ViewData["mykey"] = render;
            return View();
        }
	}
}