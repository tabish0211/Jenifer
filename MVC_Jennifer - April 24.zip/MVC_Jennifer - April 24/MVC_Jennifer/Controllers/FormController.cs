﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using MVC_Jennifer.Models;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace MVC_Jennifer.Controllers
{
    public class FormController : Controller
    {
        //
        // GET: /Form/Index
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Save(Employee emp)
        {
            //ADO.Net to send record from C# sql server

            //connection string---Is a channel detail for C#
            //DESKTOP-U7L63BC\SQLEXPRESS--Server
            //JenniferDb
            //Windows Authentication use Integrated Security=true;
            //Above has to add in web.config

            //System.Data;
            //System.Data.SqlClient;
            //System.Configuration;
            //Make Connection Object
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString());
            //open the connection
            con.Open();

            string str = "insert into employee values(@id,@name,@desg)";
            SqlCommand cmd = new SqlCommand(str,con);
            cmd.Parameters.AddWithValue("@id", emp.ID);
            cmd.Parameters.AddWithValue("@name", emp.Name);
            cmd.Parameters.AddWithValue("@desg", emp.Designation);

            int count = cmd.ExecuteNonQuery();
            con.Close();

            return View(emp);
        }
    }
}