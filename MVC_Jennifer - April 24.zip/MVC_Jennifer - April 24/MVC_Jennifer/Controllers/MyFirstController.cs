﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

//import model
using MVC_Jennifer.Models;

namespace MVC_Jennifer.Controllers
{
    public class MyFirstController : Controller
    {
        //ActionMethod

        public ActionResult HelloWorld()
        {
            return View();
        }


        public ActionResult WishMe()
        {
            return View();
        }

        //localhost:xxxx/MyFirst/Table
        public ActionResult Table()
        {
            int num = 2;
            string render = string.Empty;
            for (int i = 1; i <=10; i++)
            {
                var result=num*i;
                render = render + " " + result.ToString();
            }

            ViewData["mykey"] = render;
            return View();
        }
        //localhost:xxxx/MyFirst/TableViewBag

        //ViewBag is equal Viewdata it is just syntactical difference
        public ActionResult TableViewBag()
        {
            int num = 2;
            string render = string.Empty;
            for (int i = 1; i <= 10; i++)
            {
                var result = num * i;
                render = render + " " + result.ToString();
            }

            ViewBag.MyKey = render;
            return View();
        }
        //localhost:xxxx/MyFirst/TableTempData
        public ActionResult TableTempData()
        {
            int num = 2;
            string render = string.Empty;
            for (int i = 1; i <= 10; i++)
            {
                var result = num * i;
                render = render + " " + result.ToString();
            }

            TempData["MyKey"] = render;
           // return View();
            return RedirectToAction("ReceiveTempData");
        }

        
        public ActionResult ReceiveTempData()
        {
            var data = TempData["MyKey"];
            
            return View();
        }
        
        //localhost:xxxx/MyFirst/ModelDemo
        public ActionResult ModelDemo()
        {
            Employee obj = new Employee();
            obj.ID = 101;
            obj.Name = "Rohan";
            obj.Designation = "Sowftware Engineer";

            return View(obj);
        }

        //localhost:xxxx/MyFirst/ModelDemoList
        public ActionResult ModelDemoList()
        {
            Employee obj1 = new Employee();
            obj1.ID = 101;
            obj1.Name = "Rohan";
            obj1.Designation = "Sowftware Engineer";

            Employee obj2 = new Employee();
            obj2.ID = 102;
            obj2.Name = "Raj";
            obj2.Designation = "Trainee Sowftware Engineer";

            Employee obj3 = new Employee();
            obj3.ID = 103;
            obj3.Name = "Rakesh";
            obj3.Designation = "Senior Sowftware Engineer";

            List<Employee> employees = new List<Employee>();
            employees.Add(obj1);
            employees.Add(obj2);
            employees.Add(obj3);
            ViewBag.Employees = employees;

            return View();
        }
        //localhost:xxxx/MyFirst/ModelDemoAnotherList
        public ActionResult ModelDemoAnotherList()
        {
            Employee obj1 = new Employee();
            obj1.ID = 101;
            obj1.Name = "Rohan";
            obj1.Designation = "Sowftware Engineer";

            Employee obj2 = new Employee();
            obj2.ID = 102;
            obj2.Name = "Raj";
            obj2.Designation = "Trainee Sowftware Engineer";

            Employee obj3 = new Employee();
            obj3.ID = 103;
            obj3.Name = "Rakesh";
            obj3.Designation = "Senior Sowftware Engineer";

            List<Employee> employees = new List<Employee>();
            employees.Add(obj1);
            employees.Add(obj2);
            employees.Add(obj3);


            return View(employees);
        }
    }
}