﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using MVC_Jennifer.Models;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace MVC_Jennifer.Controllers
{
    public class FormController : Controller
    {
        //
        // GET: /Form/Index
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult IndexUpdate()
        {
            return View();
        }

        public ActionResult IndexDelete()
        {
            return View();
        }


        public ActionResult IndexFetch()
        {
            return View();
        }

        public ActionResult Fetch(Employee emp)
        {
            
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString());

            con.Open();

            string str = "select id,ename,desg from employee where id=@id";
            SqlCommand cmd = new SqlCommand(str, con);
            cmd.Parameters.AddWithValue("@id", emp.ID);

            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    emp.ID = Convert.ToInt32(dr["id"].ToString());
                    emp.Name = dr["ename"].ToString();
                    emp.Designation = dr["desg"].ToString();
                }

                emp.DisplayContent = "block";
                emp.DisplayMessage = "none";
            }
            else
            {
                emp.DisplayMessage = "block";
                emp.DisplayContent = "none";
            }
            dr.Close();
            con.Close();

            return View(emp);
           
        }
        public ActionResult Update(Employee emp)
        {
            
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString());
            
            con.Open();

            string str = "update employee set ename=@name,desg=@desg where id=@id";
            SqlCommand cmd = new SqlCommand(str,con);
            cmd.Parameters.AddWithValue("@id", emp.ID);
            cmd.Parameters.AddWithValue("@name", emp.Name);
            cmd.Parameters.AddWithValue("@desg", emp.Designation);

            int count = cmd.ExecuteNonQuery();
            con.Close();

            return View(emp);
        }


        public ActionResult Delete(Employee emp)
        {

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString());

            con.Open();

            string str = "delete from employee where id=@id";
            SqlCommand cmd = new SqlCommand(str, con);
            cmd.Parameters.AddWithValue("@id", emp.ID);          

            int count = cmd.ExecuteNonQuery();
            con.Close();

            return View(emp);
        }

        public ActionResult Save(Employee emp)
        {
            //ADO.Net to send record from C# sql server

            //connection string---Is a channel detail for C#
            //DESKTOP-U7L63BC\SQLEXPRESS--Server
            //JenniferDb
            //Windows Authentication use Integrated Security=true;
            //Above has to add in web.config

            //System.Data;
            //System.Data.SqlClient;
            //System.Configuration;
            //Make Connection Object
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString());
            //open the connection
            con.Open();

            string str = "insert into employee values(@id,@name,@desg)";
            SqlCommand cmd = new SqlCommand(str, con);
            cmd.Parameters.AddWithValue("@id", emp.ID);
            cmd.Parameters.AddWithValue("@name", emp.Name);
            cmd.Parameters.AddWithValue("@desg", emp.Designation);

            int count = cmd.ExecuteNonQuery();
            con.Close();

            return View(emp);
        }
    }
}