# ASP.NET MVC Ecommerce

ASP.NET MVC is one of the best web frameworks out there to develop secure, fast, enterprise web applications. The team at Microsoft is constantly working on the development of the product and updates being pushed to the framework has always been very well tested and dependable.  What I have here is a simple E-commerce application built on MVC 5, which includes a catalog, a user authentication module and a product management module. This web application is 100% free to use, you can use it as base for building a more sophisticated Web Application. Feel free to submit an issue if you found any bug or even better – submit a pull request.

## Author
### Carl Victor C. Fontanos
- Email: carl.fontanos@gmail.com
- Website: http://www.carlofontanos.com​
- Linkedin: http://ph.linkedin.com/in/carlfontanos
- Facebook: http://facebook.com/carlo.fontanos
- Twitter: http://twitter.com/carlofontanos
- Google+: https://plus.google.com/u/0/107219338853998242780/about
- GitHub: https://github.com/carlo-fontanos