﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using EntityFramework_Jennifer.Models;

namespace EntityFramework_Jennifer.Controllers
{
    public class CRUDController : Controller
    {
        //
        // GET: /CRUD/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult SaveRecord(Employee emp)
        {
            //context object
            SimpleContext context = new SimpleContext();
            context.Set<Employee>().Add(emp);
            context.SaveChanges();
            context.Dispose();

            return View();
        }

        public ActionResult UpdateRecord(Employee emp)
        {
            //context object
            SimpleContext context = new SimpleContext();
            Employee result=context.Set<Employee>().Where(e => e.Name == emp.Name).SingleOrDefault();

            if (result !=null)
            {                
                result.Salary = emp.Salary;
            }

            context.SaveChanges();
            context.Dispose();

            return View();
        }


        public ActionResult FetchRecord(Employee emp)
        {
            //context object
            SimpleContext context = new SimpleContext();
            Employee result = context.Set<Employee>().Where(e => e.Id == emp.Id).SingleOrDefault();            
            context.Dispose();

            return View(result);
        }

        public ActionResult DeleteRecord(Employee emp)
        {
            //context object
            SimpleContext context = new SimpleContext();
            Employee result = context.Set<Employee>().Where(e => e.Id == emp.Id).SingleOrDefault();
            if (result!=null)
            {
                context.Set<Employee>().Remove(result);
                context.SaveChanges();
            }
           
            context.Dispose();

            return View();
        }


        public ActionResult Crud(Employee emp,int id)
        {
            //context object
            switch (id)
            {
                case 1:
                    SaveRecord(emp);
                    break;

                default:
                    break;
            }      
            return View();
        }
	}
}