namespace EntityFramework_Jennifer.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DropColumnDobFromEmployees : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Employees", "Dob");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Employees", "Dob", c => c.String());
        }
    }
}
