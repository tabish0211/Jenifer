namespace EntityFramework_Jennifer.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedColumnDobToEmployees : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Employees", "Dob", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Employees", "Dob");
        }
    }
}
