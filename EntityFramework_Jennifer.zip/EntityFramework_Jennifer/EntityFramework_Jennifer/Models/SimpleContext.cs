﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace EntityFramework_Jennifer.Models
{
    public class SimpleContext :DbContext
    {
        public SimpleContext():base("name=constr")
        {

        }

        public DbSet<Employee> employees { get; set; }
    }
}